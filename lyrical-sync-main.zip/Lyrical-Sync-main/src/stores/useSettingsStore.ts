import { create } from "zustand";
import { persist, createJSONStorage, type StateStorage } from "zustand/middleware";
import { type KeyAction, DEFAULT_KEYBINDINGS, normalizeKeybindings } from "../utils/keybindings";

// 슬라이더 드래그처럼 짧은 시간에 set()이 연속 호출될 때마다 전체 설정 blob을
// 매번 동기적으로 localStorage에 직렬화·쓰기하지 않도록, 실제 디스크 쓰기만 디바운스.
// (인메모리 zustand 상태는 매 tick 그대로 갱신되므로 UI 반응성엔 영향 없음.)
function debouncedLocalStorage(delayMs: number): StateStorage {
  let timer: ReturnType<typeof setTimeout> | null = null;
  let pending: { key: string; value: string } | null = null;
  return {
    getItem: (key) => { try { return localStorage.getItem(key); } catch { return null; } },
    setItem: (key, value) => {
      pending = { key, value };
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        if (pending) { try { localStorage.setItem(pending.key, pending.value); } catch { /* Keep in-memory settings usable. */ } }
        pending = null;
        timer = null;
      }, delayMs);
    },
    removeItem: (key) => {
      if (timer) { clearTimeout(timer); timer = null; }
      pending = null;
      try { localStorage.removeItem(key); } catch { /* Storage can be unavailable. */ }
    },
  };
}

export function normalizeGlyphWaveformHeight(value: unknown): number {
  return typeof value === "number" && Number.isFinite(value)
    ? Math.max(80, Math.min(240, Math.round(value / 8) * 8)) : 144;
}

interface SettingsState {
  glyphWaveformHeight: number;
  glyphWaveformStyle: "continuous" | "bars";
  setGlyphWaveformHeight: (value: number) => void;
  setGlyphWaveformStyle: (value: "continuous" | "bars") => void;
  autoCheckUpdate: boolean;
  /** 저장 경로가 지정된 파일에 대해 변경 시 자동 저장 */
  autoSave: boolean;
  uiScale: number;
  /** 커스텀 모델 저장 경로. "" = 앱 기본 경로 사용 */
  modelsDir: string;
  /** 빈 줄 타임스탬프 = 앞 가사 end + blankLineOffset 초 */
  blankLineOffset: number;
  /** 글자/단어 동기화가 있어 Enhanced LRC로 저장될 때 알림 팝업 표시. false면 묻지 않고 저장 */
  showElrcSaveNotice: boolean;
  /** 가사 편집 글꼴 크기 배율 (0.8 ~ 1.5, 기본값: 1.0) */
  lyricsFontScale: number;
  /** 글자 동기화 모드에서 글자 아래 시간 마커 표시 */
  showGlyphTimeMarkers: boolean;
  /** 파형 대신/함께 스펙트로그램 표시 (음높이·배음 구조를 볼 때 유용) */
  showSpectrogram: boolean;
  /** 가사 줄 입력창에 브라우저 기본 맞춤법 검사 사용 */
  showSpellCheck: boolean;
  /** 각 가사 줄에 2차(번역) 텍스트 보조 입력창 표시 */
  showTranslationLines: boolean;
  /** 미리보기(가라오케) 글꼴 크기 배율 (0.8 ~ 1.5, 기본값: 1.0) */
  previewFontScale: number;
  /** 미리보기 활성 줄 텍스트 색상(카라오케 그라디언트 시작색 겸용) */
  previewActiveColor: string;
  /** 미리보기 언더라인 글로우 + 카라오케 그라디언트 끝색 */
  previewAccentColor: string;
  /** 미리보기 활성 줄 글로우 효과 사용 여부 */
  previewGlowEnabled: boolean;
  /** AI 정렬 시 Demucs 보컬 분리 사용(설치돼 있을 때). false면 원본 오디오로 정렬 */
  useVocalSeparation: boolean;
  /** AI 정렬 시 보컬 활동 감지(VAD) 사용 — 빈 줄 정밀 배치 + 신뢰도 보정. 보컬 분리 필요 */
  useVad: boolean;
  /** 전역 단축키 바인딩(action → KeyboardEvent.code) */
  keybindings: Record<KeyAction, string>;
  /** Spotify Developer App client_id (사용자 직접 입력) */
  spotifyClientId: string;
  /** Spotify 모드 활성화 여부 (로그인 상태와 독립적으로 UI 전환) */
  spotifyMode: boolean;
  /** YouTube 모드 활성화 여부 */
  youtubeMode: boolean;
  /** 기기 감지 모드 활성화 여부(Windows SMTC로 로컬 재생 중인 미디어 감지, Windows 전용) */
  deviceMode: boolean;
  /** yt-dlp 오디오 품질 */
  ytdlpAudioQuality: "best" | "192" | "128";
  /** yt-dlp 쿠키 파일 경로 (로그인 필요 콘텐츠용) */
  ytdlpCookiesFile: string;
  /** yt-dlp 프록시 설정 */
  ytdlpProxy: string;
  /** YouTube 다운로드 면책 고지에 1회 동의했는지 */
  youtubeDisclaimerAccepted: boolean;
  /** 최근 연 파일(가사/오디오) 목록, 최신순 최대 8개 */
  recentFiles: RecentFileEntry[];
  setAutoCheckUpdate: (v: boolean) => void;
  setAutoSave: (v: boolean) => void;
  setUiScale: (v: number) => void;
  setModelsDir: (v: string) => void;
  setBlankLineOffset: (v: number) => void;
  setShowElrcSaveNotice: (v: boolean) => void;
  setLyricsFontScale: (v: number) => void;
  setShowGlyphTimeMarkers: (v: boolean) => void;
  setShowSpectrogram: (v: boolean) => void;
  setShowSpellCheck: (v: boolean) => void;
  setShowTranslationLines: (v: boolean) => void;
  setPreviewFontScale: (v: number) => void;
  setPreviewActiveColor: (v: string) => void;
  setPreviewAccentColor: (v: string) => void;
  setPreviewGlowEnabled: (v: boolean) => void;
  setUseVocalSeparation: (v: boolean) => void;
  setUseVad: (v: boolean) => void;
  setKeybinding: (action: KeyAction, code: string) => void;
  resetKeybindings: () => void;
  setSpotifyClientId: (v: string) => void;
  setSpotifyMode: (v: boolean) => void;
  setYoutubeMode: (v: boolean) => void;
  setDeviceMode: (v: boolean) => void;
  setYtdlpAudioQuality: (v: "best" | "192" | "128") => void;
  setYtdlpCookiesFile: (v: string) => void;
  setYtdlpProxy: (v: string) => void;
  setYoutubeDisclaimerAccepted: (v: boolean) => void;
  /** 최근 파일 항목 추가(같은 조합이 이미 있으면 맨 앞으로 이동, 최대 8개 유지) */
  addRecentFile: (entry: { lrcPath: string | null; audioPath: string | null }) => void;
  clearRecentFiles: () => void;
}

export interface RecentFileEntry {
  lrcPath: string | null;
  audioPath: string | null;
  openedAt: number;
}

const MAX_RECENT_FILES = 8;
const isPreviewColor = (value: unknown): value is string => typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value);
function restoreSettings(value: unknown, current: SettingsState): SettingsState {
  if (!value || typeof value !== "object" || Array.isArray(value)) return current;
  const saved = value as Record<string, unknown>;
  const next = { ...current };
  for (const key of Object.keys(current) as (keyof SettingsState)[]) {
    const original = current[key]; const restored = saved[key];
    if (typeof original === "boolean" && typeof restored === "boolean" || typeof original === "string" && typeof restored === "string") {
      Object.assign(next, { [key]: restored });
    }
  }
  const range = (key: "uiScale" | "lyricsFontScale" | "previewFontScale" | "blankLineOffset", min: number, max: number) => {
    const item = saved[key];
    if (typeof item === "number" && Number.isFinite(item) && item >= min && item <= max) next[key] = item;
  };
  range("uiScale", .7, 1.3); range("lyricsFontScale", .8, 1.5); range("previewFontScale", .8, 1.5); range("blankLineOffset", 0, 10);
  next.glyphWaveformHeight = normalizeGlyphWaveformHeight(saved.glyphWaveformHeight);
  next.glyphWaveformStyle = saved.glyphWaveformStyle === "bars" ? "bars" : "continuous";
  next.previewActiveColor = isPreviewColor(saved.previewActiveColor) ? saved.previewActiveColor : current.previewActiveColor;
  next.previewAccentColor = isPreviewColor(saved.previewAccentColor) ? saved.previewAccentColor : current.previewAccentColor;
  next.ytdlpAudioQuality = ["best", "192", "128"].includes(String(saved.ytdlpAudioQuality)) ? saved.ytdlpAudioQuality as SettingsState["ytdlpAudioQuality"] : current.ytdlpAudioQuality;
  next.keybindings = normalizeKeybindings(saved.keybindings && typeof saved.keybindings === "object" && !Array.isArray(saved.keybindings) ? Object.fromEntries(Object.entries(saved.keybindings).filter(([, value]) => typeof value === "string")) : undefined);
  if (Array.isArray(saved.recentFiles)) next.recentFiles = saved.recentFiles.filter((entry): entry is RecentFileEntry =>
    !!entry && typeof entry === "object" && (entry.lrcPath === null || typeof entry.lrcPath === "string") &&
    (entry.audioPath === null || typeof entry.audioPath === "string") && typeof entry.openedAt === "number" && Number.isFinite(entry.openedAt)).slice(0, MAX_RECENT_FILES);
  return next;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      glyphWaveformHeight: 144,
      glyphWaveformStyle: "continuous",
      setGlyphWaveformHeight: (v) => set({ glyphWaveformHeight: normalizeGlyphWaveformHeight(v) }),
      setGlyphWaveformStyle: (v) => set({ glyphWaveformStyle: v === "bars" ? "bars" : "continuous" }),
      autoCheckUpdate: true,
      autoSave: true,
      uiScale: 1.0,
      modelsDir: "",
      blankLineOffset: 1.0,
      showElrcSaveNotice: true,
      lyricsFontScale: 1.0,
      showGlyphTimeMarkers: true,
      showSpectrogram: false,
      showSpellCheck: false,
      showTranslationLines: false,
      previewFontScale: 1.0,
      previewActiveColor: "#ffffff",
      previewAccentColor: "#6366f1",
      previewGlowEnabled: true,
      useVocalSeparation: true,
      useVad: true,
      keybindings: { ...DEFAULT_KEYBINDINGS },
      spotifyClientId: "",
      spotifyMode: false,
      youtubeMode: false,
      deviceMode: false,
      ytdlpAudioQuality: "best",
      ytdlpCookiesFile: "",
      ytdlpProxy: "",
      youtubeDisclaimerAccepted: false,
      recentFiles: [],
      setAutoCheckUpdate: (v) => set({ autoCheckUpdate: v }),
      setAutoSave: (v) => set({ autoSave: v }),
      setUiScale: (v) => set({ uiScale: v }),
      setModelsDir: (v) => set({ modelsDir: v }),
      setBlankLineOffset: (v) => set({ blankLineOffset: v }),
      setShowElrcSaveNotice: (v) => set({ showElrcSaveNotice: v }),
      setLyricsFontScale: (v) => set({ lyricsFontScale: v }),
      setShowGlyphTimeMarkers: (v) => set({ showGlyphTimeMarkers: v }),
      setShowSpectrogram: (v) => set({ showSpectrogram: v }),
      setShowSpellCheck: (v) => { if (typeof v === "boolean") set({ showSpellCheck: v }); },
      setShowTranslationLines: (v) => { if (typeof v === "boolean") set({ showTranslationLines: v }); },
      setPreviewFontScale: (v) => { if (Number.isFinite(v) && v >= .8 && v <= 1.5) set({ previewFontScale: v }); },
      setPreviewActiveColor: (v) => { if (isPreviewColor(v)) set({ previewActiveColor: v }); },
      setPreviewAccentColor: (v) => { if (isPreviewColor(v)) set({ previewAccentColor: v }); },
      setPreviewGlowEnabled: (v) => { if (typeof v === "boolean") set({ previewGlowEnabled: v }); },
      setUseVocalSeparation: (v) => set({ useVocalSeparation: v }),
      setUseVad: (v) => set({ useVad: v }),
      setKeybinding: (action, code) =>
        set((s) => ({ keybindings: { ...s.keybindings, [action]: code } })),
      resetKeybindings: () => set({ keybindings: { ...DEFAULT_KEYBINDINGS } }),
      setSpotifyClientId: (v) => set({ spotifyClientId: v }),
      setSpotifyMode: (v) => set({ spotifyMode: v }),
      setYoutubeMode: (v) => set({ youtubeMode: v }),
      setDeviceMode: (v) => set({ deviceMode: v }),
      setYtdlpAudioQuality: (v) => set({ ytdlpAudioQuality: v }),
      setYtdlpCookiesFile: (v) => set({ ytdlpCookiesFile: v }),
      setYtdlpProxy: (v) => set({ ytdlpProxy: v }),
      setYoutubeDisclaimerAccepted: (v) => set({ youtubeDisclaimerAccepted: v }),
      addRecentFile: (entry) =>
        set((s) => {
          if (!entry.lrcPath && !entry.audioPath) return s;
          const sameEntry = (f: RecentFileEntry) => f.lrcPath === entry.lrcPath && f.audioPath === entry.audioPath;
          const next = [{ ...entry, openedAt: Date.now() }, ...s.recentFiles.filter((f) => !sameEntry(f))];
          return { recentFiles: next.slice(0, MAX_RECENT_FILES) };
        }),
      clearRecentFiles: () => set({ recentFiles: [] }),
    }),
    { name: "lyrical-sync-settings", storage: createJSONStorage(() => debouncedLocalStorage(300)),
      merge: (persisted, current) => restoreSettings(persisted, current),
    }
  )
);
