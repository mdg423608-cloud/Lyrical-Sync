import { useEffect, useState } from "react";
import { openUrl } from "@tauri-apps/plugin-opener";
import { useI18nStore } from "../../stores/useI18nStore";
import { useSettingsStore } from "../../stores/useSettingsStore";
import { normalizeKeybindings, keyLabel } from "../../utils/keybindings";

export function HelpModal({ onClose }: { onClose: () => void }) {
  const { t, lang } = useI18nStore();
  const kb = normalizeKeybindings(useSettingsStore((s) => s.keybindings));

  const guideFileSuffix = lang === "ko" ? "ko" : lang === "ja" ? "ja" : "en";
  const aiGuideUrl = `https://ahri2nd.xyz/posts/lyrical-sync-ai-installation-guide-${guideFileSuffix}/`;
  const spotifyGuideUrl = `https://ahri2nd.xyz/posts/lyrical-sync-spotify-guide-${guideFileSuffix}/`;
  const youtubeGuideUrl = `https://ahri2nd.xyz/posts/lyrical-sync-youtube-guide-${guideFileSuffix}/`;
  const [tab, setTab] = useState<"shortcuts" | "ai" | "spotify" | "youtube">("shortcuts");

  const shortcutGroups = [
    {
      title: t.helpGroupPlayback,
      items: [
        { key: keyLabel(kb.skipBack5), desc: t.shortcutDescs.s1 },
        { key: keyLabel(kb.skipBack1), desc: t.shortcutDescs.s2 },
        { key: keyLabel(kb.playPause), desc: t.shortcutDescs.s3 },
        { key: keyLabel(kb.skipFwd1), desc: t.shortcutDescs.s4 },
        { key: keyLabel(kb.skipFwd5), desc: t.shortcutDescs.s5 },
        { key: keyLabel(kb.stop), desc: t.shortcutDescs.s6 },
      ],
    },
    {
      title: t.helpGroupEdit,
      items: [
        { key: keyLabel(kb.stamp), desc: t.shortcutDescs.space },
        { key: keyLabel(kb.prevLine), desc: t.shortcutDescs.backspace },
        { key: "Enter", desc: t.shortcutDescs.enter },
        { key: "⇧ Enter", desc: t.shortcutDescs.splitLine },
        { key: "Ctrl/⌘ Z", desc: t.shortcutDescs.undo },
        { key: "Ctrl/⌘ ⇧ Z", desc: t.shortcutDescs.redo },
        { key: "Ctrl/⌘ F", desc: t.shortcutDescs.find },
      ],
    },
    {
      title: t.helpGroupMouse,
      items: [
        { key: t.shortcutDescs.tsEditKey, desc: t.shortcutDescs.tsEditDesc },
        { key: t.shortcutDescs.tsStampKey, desc: t.shortcutDescs.tsStampDesc },
        { key: t.shortcutDescs.lineClickKey, desc: t.shortcutDescs.lineClickDesc },
        { key: t.shortcutDescs.markerClickKey, desc: t.shortcutDescs.markerClickDesc },
      ],
    },
    {
      title: t.helpGroupCharSync,
      items: [
        { key: keyLabel(kb.stamp), desc: t.shortcutDescs.csStamp },
        { key: "← / →", desc: t.shortcutDescs.csMove },
        { key: t.shortcutDescs.csNudgeKey, desc: t.shortcutDescs.csNudgeDesc },
        { key: t.shortcutDescs.csDragKey, desc: t.shortcutDescs.csDragDesc },
        { key: t.shortcutDescs.csClickKey, desc: t.shortcutDescs.csClickDesc },
        { key: t.shortcutDescs.csClearKey, desc: t.shortcutDescs.csClearDesc },
      ],
    },
  ];

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  const tabs = [
    { id: "shortcuts" as const, label: t.helpTabShortcuts },
    { id: "ai" as const, label: t.helpTabAi },
    { id: "spotify" as const, label: t.helpTabSpotify },
    { id: "youtube" as const, label: t.helpTabYouTube },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-[var(--ls-surface)] border border-[var(--ls-border-subtle)] rounded-xl shadow-2xl w-full max-w-2xl mx-4 max-h-[calc(100%-2rem)] flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[var(--ls-border-subtle)] shrink-0">
          <span className="font-semibold text-[var(--ls-text)]">{t.helpTitle}</span>
          <button
            onClick={onClose}
            aria-label={t.close}
            className="ls-button hover:text-white transition-colors text-lg leading-none"
          >
            ✕
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[var(--ls-border-subtle)] shrink-0">
          {tabs.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`ls-button ${[
                "flex-1 py-2 text-xs font-medium transition-colors",
                tab === id
                  ? "text-[var(--ls-accent)] border-b-2 border-[var(--ls-accent)]"
                  : "text-[var(--ls-text-secondary)] hover:text-[var(--ls-text-secondary)]",
              ].join(" ")}`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto">
          {tab === "shortcuts" && (
            <div className="flex flex-col gap-5">
              {shortcutGroups.map((g) => (
                <div key={g.title}>
                  <h3 className="text-xs font-semibold text-[var(--ls-text-secondary)] mb-2.5">{g.title}</h3>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-2.5">
                    {g.items.map(({ key, desc }) => (
                      <div key={key} className="flex items-center gap-3">
                        <kbd className="shrink-0 min-w-[3rem] text-center px-2 py-1 rounded-md bg-[var(--ls-control)] border border-[var(--ls-border-control)] text-xs font-mono text-[var(--ls-text)] whitespace-nowrap">
                          {key}
                        </kbd>
                        <span className="text-sm text-[var(--ls-text-secondary)] leading-snug">{desc}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              <p className="text-xs text-[var(--ls-text-secondary)] pt-1">{t.shortcutNote}</p>
            </div>
          )}

          {tab === "ai" && (
            <div className="flex flex-col gap-4">
              <button
                onClick={() => openUrl(aiGuideUrl)}
                className="ls-button self-start text-xs text-[var(--ls-accent)] hover:text-[var(--ls-accent)] transition-colors underline underline-offset-2"
              >
                {t.helpViewGuide}
              </button>
              {t.helpAiSteps.map(({ title, desc }, i) => (
                <div key={i} className="flex gap-3">
                  <span className="shrink-0 w-5 h-5 rounded-full bg-[var(--ls-primary)] text-white text-xs flex items-center justify-center font-bold mt-0.5">
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-medium text-[var(--ls-text)] mb-0.5">{title}</p>
                    <p className="text-xs text-[var(--ls-text-secondary)] leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "spotify" && (
            <div className="flex flex-col gap-4">
              <button
                onClick={() => openUrl(spotifyGuideUrl)}
                className="ls-button self-start text-xs text-green-500 hover:text-green-400 transition-colors underline underline-offset-2"
              >
                {t.helpViewGuide}
              </button>
              {t.helpSpotifySteps.map(({ title, desc }, i) => (
                <div key={i} className="flex gap-3">
                  <span className="shrink-0 w-5 h-5 rounded-full bg-green-700 text-white text-xs flex items-center justify-center font-bold mt-0.5">
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-medium text-[var(--ls-text)] mb-0.5">{title}</p>
                    <p className="text-xs text-[var(--ls-text-secondary)] leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === "youtube" && (
            <div className="flex flex-col gap-4">
              <button
                onClick={() => openUrl(youtubeGuideUrl)}
                className="ls-button self-start text-xs text-red-400 hover:text-red-300 transition-colors underline underline-offset-2"
              >
                {t.helpViewGuide}
              </button>
              {t.helpYoutubeSteps.map(({ title, desc }, i) => (
                <div key={i} className="flex gap-3">
                  <span className="shrink-0 w-5 h-5 rounded-full bg-red-700 text-white text-xs flex items-center justify-center font-bold mt-0.5">
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-medium text-[var(--ls-text)] mb-0.5">{title}</p>
                    <p className="text-xs text-[var(--ls-text-secondary)] leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
