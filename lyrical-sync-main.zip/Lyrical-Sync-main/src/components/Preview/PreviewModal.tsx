import { isComposingKeyEvent } from "../../utils/keybindings";
import { useEffect, useRef, useMemo, useCallback, useState } from "react";
import { useShallow } from "zustand/react/shallow";
import { useLrcStore } from "../../stores/useLrcStore";
import { useI18nStore } from "../../stores/useI18nStore";
import { useSettingsStore } from "../../stores/useSettingsStore";
import { useServiceStore } from "../../stores/useServiceStore";
import { audioControls } from "../../utils/audioControls";
import { serviceControls } from "../../utils/serviceControls";
import { formatDisplayTime, parseTimestampInput, isStampable } from "../../utils/lrcParser";
import type { LrcSyllable } from "../../types/lrc";
import { GearIcon } from "../AppShell/icons";

// "#rrggbb" → "rgba(r,g,b,alpha)" — 사용자 지정 색상에 투명도를 적용할 때 사용
// (previewActiveColor/previewAccentColor는 hex 문자열로 저장되므로 Tailwind 클래스로는 표현 불가)
function hexToRgba(hex: string, alpha: number): string {
  const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex);
  if (!m) return `rgba(255,255,255,${alpha})`;
  const [r, g, b] = [m[1], m[2], m[3]].map((h) => parseInt(h, 16));
  return `rgba(${r},${g},${b},${alpha})`;
}

// 비활성 줄의 거리별 흐림 정도(기존 text-zinc-300/500/700 근사) — previewActiveColor를
// 기준으로 opacity만 낮춰 파생하므로 사용자가 활성 색을 바꿔도 톤이 일관됨
const DIST_OPACITY: Record<number, number> = { 0: 1, 1: 0.75, 2: 0.45 };
const DIST_OPACITY_FAR = 0.22;

// 거리별 글꼴 크기(기존 text-2xl/xl/lg/base의 rem 값) × previewFontScale
const DIST_FONT_REM: Record<number, number> = { 0: 1.5, 1: 1.25, 2: 1.125 };
const DIST_FONT_REM_FAR = 1;

export function PreviewModal({ onClose, onOpenStyleSettings }: { onClose: () => void; onOpenStyleSettings: () => void }) {
  const { doc, currentTime, duration, isPlaying, updateLine } = useLrcStore(
    useShallow((s) => ({
      doc: s.doc,
      currentTime: s.currentTime,
      duration: s.duration,
      isPlaying: s.isPlaying,
      updateLine: s.updateLine,
    }))
  );
  const spotifyMode = useSettingsStore((s) => s.spotifyMode);
  const previewFontScale = useSettingsStore((s) => s.previewFontScale);
  const previewActiveColor = useSettingsStore((s) => s.previewActiveColor);
  const previewAccentColor = useSettingsStore((s) => s.previewAccentColor);
  const previewGlowEnabled = useSettingsStore((s) => s.previewGlowEnabled);
  const serviceLoggedIn = useServiceStore((s) => s.isLoggedIn);
  const servicePositionMs = useServiceStore((s) => s.positionMs);
  const serviceDurationMs = useServiceStore((s) => s.durationMs);
  const serviceIsPlaying = useServiceStore((s) => s.isPlaying);
  const { t } = useI18nStore();
  const activeLineRef = useRef<HTMLDivElement>(null);
  const isServiceMode = serviceLoggedIn && spotifyMode;
  const controls = isServiceMode ? serviceControls : audioControls;
  const playbackTime = isServiceMode ? servicePositionMs / 1000 : currentTime;
  const playbackDuration = isServiceMode ? serviceDurationMs / 1000 : duration;
  const playbackIsPlaying = isServiceMode ? serviceIsPlaying : isPlaying;

  // 인라인 타임스탬프 편집 상태
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const editInputRef = useRef<HTMLInputElement>(null);

  // 현재 시각 기준으로 활성 줄 인덱스 계산
  const activeIdx = useMemo(() => {
    let idx = -1;
    for (let i = 0; i < doc.lines.length; i++) {
      const ts = doc.lines[i].timestamp;
      if (ts !== null && ts <= playbackTime) idx = i;
    }
    return idx;
  }, [doc.lines, playbackTime]);

  // 각 줄의 가라오케 종료 시각을 1회 O(n) 패스로 미리 계산
  // (기존엔 줄마다 앞쪽 스캔 → 렌더당 O(n²)이 매 프레임 실행됐음)
  const lineEnds = useMemo(() => {
    const ends = new Array<number>(doc.lines.length);
    let nextStampedTs: number | null = null;
    for (let i = doc.lines.length - 1; i >= 0; i--) {
      ends[i] = nextStampedTs !== null
        ? nextStampedTs
        : (playbackDuration > 0 ? playbackDuration : (doc.lines[i].timestamp ?? 0) + 4);
      if (doc.lines[i].timestamp !== null) nextStampedTs = doc.lines[i].timestamp;
    }
    return ends;
  }, [doc.lines, playbackDuration]);

  // 활성 줄이 바뀔 때 스크롤 (편집 중이 아닐 때만)
  useEffect(() => {
    if (editingId) return;
    activeLineRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [activeIdx, editingId]);

  // 편집 인풋 자동 포커스
  useEffect(() => {
    if (editingId) editInputRef.current?.focus();
  }, [editingId]);

  // ESC: 편집 중이면 편집 취소, 아니면 모달 닫기
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (isComposingKeyEvent(e)) return;
      if (e.key === "Escape") {
        if (editingId) {
          setEditingId(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose, editingId]);

  const togglePlay = useCallback(() => controls.togglePlay(), [controls]);
  const skip = useCallback((d: number) => controls.skip(d), [controls]);

  const startEdit = useCallback((id: string, currentTs: number | null) => {
    setEditingId(id);
    setEditValue(currentTs !== null ? formatDisplayTime(currentTs) : "");
  }, []);

  const commitEdit = useCallback((id: string) => {
    const parsed = parseTimestampInput(editValue);
    const current = useLrcStore.getState().doc.lines.find((line) => line.id === id)?.timestamp;
    if (parsed !== null && parsed !== current && (current == null || editValue.trim() !== formatDisplayTime(current))) {
      updateLine(id, { timestamp: parsed });
    }
    setEditingId(null);
  }, [editValue, updateLine]);

  // 줄 클릭 시 시크(+정지 상태면 재생). 재생 상태는 fresh로 읽어 목록 메모 의존성에서 제외
  const seekToLine = useCallback((ts: number) => {
    controls.seekTo(ts);
    const playing = isServiceMode ? useServiceStore.getState().isPlaying : useLrcStore.getState().isPlaying;
    if (!playing) controls.togglePlay();
  }, [controls, isServiceMode]);

  // 줄 목록을 메모화 → 부모가 매 프레임(currentTime) 리렌더돼도 활성 줄 전환·편집 시에만 재구성.
  // 활성 줄의 가라오케 채움은 KaraokeText가 시간을 자체 구독해 갱신.
  const linesContent = useMemo(() => doc.lines.map((line, i) => {
    const dist = activeIdx === -1 ? 999 : Math.abs(i - activeIdx);
    const isActive = i === activeIdx;
    const hasGlyphSync = !!line.syllables?.some((s) => s.time !== null);
    const lineEnd = lineEnds[i];

    const lineColor = hexToRgba(previewActiveColor, isActive ? 1 : (DIST_OPACITY[dist] ?? DIST_OPACITY_FAR));
    const fontWeightClass = isActive ? "font-semibold" : dist === 1 ? "font-medium" : "";
    const fontRem = (DIST_FONT_REM[dist] ?? DIST_FONT_REM_FAR) * previewFontScale;

    return (
      <div
        key={line.id}
        ref={isActive ? activeLineRef : null}
        className="flex items-baseline gap-4 transition-all duration-300"
        style={{ color: lineColor }}
      >
        <div className="w-28 shrink-0 flex justify-end">
          {editingId === line.id ? (
            <input
              ref={editInputRef}
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              onBlur={() => commitEdit(line.id)}
              onKeyDown={(e) => {
                e.stopPropagation();
                if (isComposingKeyEvent(e.nativeEvent)) return;
                if (e.key === "Enter") commitEdit(line.id);
                if (e.key === "Escape") setEditingId(null);
              }}
              placeholder="H:MM:SS.mmm"
              className="ls-field ls-row-input ls-time-input w-full text-xs font-mono"
            />
          ) : (
            <button
              onClick={() => startEdit(line.id, line.timestamp)}
              className={`ls-button ls-button--compact ls-time-button ${`font-mono text-xs transition-colors w-full
                ${line.timestamp !== null
                  ? "hover:bg-[var(--ls-control)] hover:text-[var(--ls-accent)]"
                  : "text-[var(--ls-text-secondary)] hover:bg-[var(--ls-control)] hover:text-[var(--ls-text-secondary)]"
                }`}`}
            >
              {line.timestamp !== null ? formatDisplayTime(line.timestamp) : "—"}
            </button>
          )}
        </div>

        <div
          className={`flex-1 leading-snug ${fontWeightClass} ${line.timestamp !== null ? "cursor-pointer" : "select-none"}`}
          style={{
            fontSize: `${fontRem}rem`,
            whiteSpace: "pre-wrap",
            textShadow: isActive && previewGlowEnabled ? `0 0 26px ${hexToRgba(previewAccentColor, 0.28)}` : undefined,
          }}
          onClick={() => { if (line.timestamp !== null) seekToLine(line.timestamp); }}
        >
          {isActive ? (
            <span className="relative inline-block">
              {hasGlyphSync && line.syllables ? (
                <KaraokeText syllables={line.syllables} lineEnd={lineEnd} isServiceMode={isServiceMode} activeColor={previewActiveColor} />
              ) : (
                line.text || " "
              )}
              <span
                className="absolute -bottom-1.5 left-0 right-0 h-px"
                style={{
                  backgroundColor: previewAccentColor,
                }}
              />
            </span>
          ) : (
            line.text || " "
          )}
          {line.translation && (
            <div
              className="text-sm font-sans not-italic mt-0.5"
              style={{ whiteSpace: "pre-wrap", color: isActive ? hexToRgba(previewAccentColor, 0.7) : hexToRgba(previewActiveColor, 0.35) }}
            >
              {line.translation}
            </div>
          )}
        </div>
      </div>
    );
  }), [doc.lines, activeIdx, lineEnds, editingId, editValue, startEdit, commitEdit, seekToLine, isServiceMode, previewFontScale, previewActiveColor, previewAccentColor, previewGlowEnabled]);

  const hasTimestamps = doc.lines.some((l) => l.timestamp !== null);

  const progress = playbackDuration > 0 ? playbackTime / playbackDuration : 0;

  const handleSeek = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!playbackDuration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    controls.seekTo(ratio * playbackDuration);
  }, [controls, playbackDuration]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[var(--ls-canvas)]">
      {/* 진행 상태바 */}
      <div
        className="shrink-0 h-1 bg-[var(--ls-control)] cursor-pointer group"
        onClick={handleSeek}
      >
        <div
          className="h-full bg-[var(--ls-accent)] group-hover:bg-[var(--ls-accent)] transition-colors relative"
          style={{ width: `${progress * 100}%` }}
        >
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-[var(--ls-accent)] opacity-0 group-hover:opacity-100 transition-opacity translate-x-1/2" />
        </div>
      </div>

      {/* 상단 바 */}
      <div className="shrink-0 flex items-center justify-between px-6 py-4 border-b border-[var(--ls-border-subtle)]/60">
        <div className="flex flex-col gap-0.5 min-w-0">
          <span className="text-white font-sans text-lg tracking-tight truncate leading-tight">
            {doc.metadata.title || t.previewUntitled}
          </span>
          {doc.metadata.artist && (
            <span className="text-[var(--ls-text-secondary)] font-sans text-sm truncate leading-tight">
              {doc.metadata.artist}
            </span>
          )}
        </div>

        {/* 재생 컨트롤 */}
        <div className="flex items-center gap-3 mx-6">
          <PreviewBtn onClick={() => skip(-5)} title="-5s">
            <SkipBackIcon /><span className="text-[10px] font-bold ml-0.5">5</span>
          </PreviewBtn>
          <PreviewBtn onClick={() => skip(-1)} title="-1s">
            <TriLeftIcon /><span className="text-[10px] font-bold ml-0.5">1</span>
          </PreviewBtn>
          <PreviewBtn onClick={togglePlay} title={t.keys.playPause} pressed={playbackIsPlaying} accent>
            {playbackIsPlaying ? <PauseIcon /> : <PlayIcon />}
          </PreviewBtn>
          <PreviewBtn onClick={() => skip(1)} title="+1s">
            <span className="text-[10px] font-bold mr-0.5">1</span><TriRightIcon />
          </PreviewBtn>
          <PreviewBtn onClick={() => skip(5)} title="+5s">
            <span className="text-[10px] font-bold mr-0.5">5</span><SkipFwdIcon />
          </PreviewBtn>
          <span className="font-mono text-xs text-[var(--ls-text-secondary)] tabular-nums w-24 text-center">
            {formatDisplayTime(playbackTime)}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onOpenStyleSettings}
            title={t.previewStyleSettingsTooltip}
            aria-label={t.previewStyleSettingsTooltip}
            className="ls-button ls-button--icon w-8 h-8 flex items-center justify-center hover:text-white transition-colors"
          >
            <GearIcon />
          </button>
          <button
            onClick={onClose}
            className="ls-button text-sm hover:text-white transition-colors"
          >
            {t.previewClose}
          </button>
        </div>
      </div>

      {/* 가사 영역 */}
      <div
        className="flex-1 min-h-0 overflow-y-auto py-20 px-8"
        style={{ scrollbarWidth: "none" }}
      >
        {doc.lines.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <span className="text-[var(--ls-text-secondary)] font-sans text-lg">{t.previewNoLyrics}</span>
          </div>
        ) : (
          <div className="flex flex-col gap-4 max-w-2xl mx-auto font-sans">
            {!hasTimestamps && (
              <p className="text-[var(--ls-text-secondary)] text-sm text-center mb-2 not-italic font-sans">{t.previewNoTimestamps}</p>
            )}
            {linesContent}
            <div className="h-24 shrink-0" />
          </div>
        )}
      </div>
    </div>
  );
}

// 글자 단위 가라오케 채움: 각 글자를 시작~다음 시각 사이 진행도로 좌→우 채움
// 시간을 자체 구독 → 부모(미리보기 목록)가 매 프레임 리렌더되지 않아도 활성 줄만 채움 갱신
function KaraokeText({
  syllables, lineEnd, isServiceMode, activeColor,
}: {
  syllables: LrcSyllable[];
  lineEnd: number;
  isServiceMode: boolean;
  activeColor: string;
}) {
  const ct = useLrcStore((s) => s.currentTime);
  const pos = useServiceStore((s) => s.positionMs);
  const currentTime = isServiceMode ? pos / 1000 : ct;
  return (
    <>
      {syllables.map((s, i) => {
        if (!isStampable(s)) return <span key={i}>{s.text}</span>;
        if (s.time === null) return <span key={i} style={{ color: "#52525b" }}>{s.text}</span>;
        // 다음 시각이 있는 글자(없으면 줄 종료)까지를 이 글자의 지속 구간으로
        let nextT = lineEnd;
        for (let j = i + 1; j < syllables.length; j++) {
          if (syllables[j].time !== null) { nextT = syllables[j].time as number; break; }
        }
        const start = s.time;
        const fill =
          nextT > start
            ? Math.max(0, Math.min(1, (currentTime - start) / (nextT - start)))
            : currentTime >= start ? 1 : 0;
        const pct = fill * 100;
        return (
          <span
            key={i}
            style={{
              background: `linear-gradient(90deg, ${activeColor} ${pct}%, #6b7280 ${pct}%)`,
              WebkitBackgroundClip: "text",
              backgroundClip: "text",
              WebkitTextFillColor: "transparent",
              color: "transparent",
            }}
          >
            {s.text}
          </span>
        );
      })}
    </>
  );
}

function PreviewBtn({
  onClick, title, accent, pressed, children,
}: {
  onClick: () => void;
  title?: string;
  accent?: boolean;
  pressed?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      aria-label={title}
      aria-pressed={pressed}
      className={`ls-button ${[
        "flex items-center justify-center text-sm transition-colors",
        accent
          ? "ls-button--play"
          : "h-9 px-2 rounded-lg text-[var(--ls-text-secondary)] hover:bg-white/10 hover:text-white",
      ].join(" ")}`}
    >
      {children}
    </button>
  );
}

function PlayIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M8 5v14l11-7z" />
    </svg>
  );
}

function PauseIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
    </svg>
  );
}

function SkipBackIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
      <path d="M11 6 L11 18 L4 12 Z M18 6 L18 18 L11 12 Z" />
    </svg>
  );
}

function SkipFwdIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor">
      <path d="M6 6 L6 18 L13 12 Z M13 6 L13 18 L20 12 Z" />
    </svg>
  );
}

function TriLeftIcon() {
  return <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M15 6 L15 18 L7 12 Z" /></svg>;
}

function TriRightIcon() {
  return <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M9 6 L9 18 L17 12 Z" /></svg>;
}
