// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render } from "@testing-library/react";
import { useI18nStore } from "../../stores/useI18nStore";
import { CharSyncView } from "./CharSyncView";
import { audioControls } from "../../utils/audioControls";
import { serviceControls } from "../../utils/serviceControls";
import { useLrcStore } from "../../stores/useLrcStore";
import { useSettingsStore } from "../../stores/useSettingsStore";
import { useServiceStore } from "../../stores/useServiceStore";
import { defaultDocument } from "../../types/lrc";
import { formatTimestamp, parseTimestampInput } from "../../utils/lrcParser";

let rafCallbacks: FrameRequestCallback[];
let seekSpy: ReturnType<typeof vi.spyOn>;

function resetStores() {
  useLrcStore.setState({
    doc: { ...defaultDocument(), lines: [{ id: "line-1", timestamp: 10, text: "hello" }] },
    activeLineId: "line-1",
    audioPath: "/music/song.mp3",
    currentTime: 12,
    isPlaying: false,
    loopLineId: null,
    duration: 100,
    syncMode: "char",
    syncUnit: "char",
    activeSyllableIndex: 0,
    _history: [],
    _future: [],
  });
  useSettingsStore.setState({ spotifyMode: false, deviceMode: false, glyphWaveformStyle: "bars", glyphWaveformHeight: 96, showGlyphTimeMarkers: true });
  useServiceStore.setState({ isLoggedIn: false });
}

function setup() {
  const view = render(<CharSyncView />);
  const lane = view.container.querySelector('[data-testid="glyph-seek-lane"]') as HTMLDivElement;
  vi.spyOn(lane, "getBoundingClientRect").mockReturnValue({
    x: 0, y: 0, left: 0, top: 0, right: 100, bottom: 40, width: 100, height: 40,
    toJSON: () => ({}),
  });
  return { ...view, lane, playhead: lane.querySelector('[data-testid="glyph-playhead"]') as HTMLDivElement };
}

beforeEach(() => {
  vi.stubGlobal("PointerEvent", class extends MouseEvent {
    pointerId: number;
    isPrimary: boolean;
    constructor(type: string, init: PointerEventInit = {}) {
      super(type, init);
      this.pointerId = init.pointerId ?? 1;
      this.isPrimary = init.isPrimary ?? true;
    }
  });
  rafCallbacks = [];
  vi.stubGlobal("requestAnimationFrame", (callback: FrameRequestCallback) => {
    rafCallbacks.push(callback);
    return rafCallbacks.length;
  });
  vi.stubGlobal("cancelAnimationFrame", vi.fn());
  resetStores();
  seekSpy = vi.spyOn(audioControls, "seekTo").mockImplementation(() => {});
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  resetStores();
});

describe("CharSyncView seek lane", () => {
  it("shows the restored lyric after undo removes the split row selection", () => {
    useLrcStore.setState({
      doc: { ...defaultDocument(), lines: [{ id: "line-1", timestamp: 10, text: "helloworld" }] },
      activeLineId: "line-1",
      _history: [],
      _future: [],
    });
    const view = render(<CharSyncView />);
    act(() => useLrcStore.getState().splitLine("line-1", 5));
    expect(view.container.querySelectorAll("[data-glyph]").length).toBeGreaterThan(0);

    act(() => useLrcStore.getState().undo());

    expect(view.container.querySelectorAll("[data-glyph]").length).toBeGreaterThan(0);
    expect(useLrcStore.getState().activeLineId).toBe("line-1");
  });

  it("keeps unrelated line buttons memoized during playback updates", () => {
    const otherLine = { id: "line-2", timestamp: 20, get text() { return "next"; } };
    const readOtherText = vi.spyOn(otherLine, "text", "get");
    useLrcStore.setState({ doc: { ...defaultDocument(), lines: [
      { id: "line-1", timestamp: 10, text: "hello" }, otherLine,
    ] } });
    setup();
    readOtherText.mockClear();
    act(() => useLrcStore.setState({ currentTime: 13 }));
    expect(readOtherText).not.toHaveBeenCalled();
  });

  it("stamps the current glyph on click, skips spaces, and lets Space stamp the next glyph", () => {
    useLrcStore.setState({ doc: { ...defaultDocument(), lines: [
      { id: "line-1", timestamp: 10, text: "a b", syllables: [
        { text: "a", time: null }, { text: " ", time: null }, { text: "b", time: null },
      ] },
      { id: "line-2", timestamp: 20, text: "next" },
    ] } });
    const { getByRole } = setup();
    const stamp = getByRole("button", { name: useI18nStore.getState().t.charSync.stampHint });
    stamp.focus();
    fireEvent.click(stamp);
    expect(useLrcStore.getState().doc.lines[0].syllables?.map(s => s.time)).toEqual([12, null, null]);
    expect(useLrcStore.getState().activeSyllableIndex).toBe(2);
    expect(document.activeElement).not.toBe(stamp);
    act(() => useLrcStore.setState({ currentTime: 13 }));
    fireEvent.keyDown(window, { code: "Space" });
    expect(useLrcStore.getState().doc.lines[0].syllables?.map(s => s.time)).toEqual([12, null, 13]);
    expect(useLrcStore.getState().activeLineId).toBe("line-2");
    expect(useLrcStore.getState()._history).toHaveLength(2);
    expect(seekSpy).not.toHaveBeenCalled();
  });

  it("uses the latest playback time for consecutive stamp button clicks", () => {
    const { getByRole } = setup();
    const stamp = getByRole("button", { name: useI18nStore.getState().t.charSync.stampHint });
    fireEvent.click(stamp);
    act(() => useLrcStore.setState({ currentTime: 12.5 }));
    fireEvent.click(stamp);
    expect(useLrcStore.getState().doc.lines[0].syllables?.slice(0, 2).map(s => s.time)).toEqual([12, 12.5]);
    expect(useLrcStore.getState().activeSyllableIndex).toBe(2);
  });

  it("shows at least two seconds of context when adjacent lyric timestamps are very close", () => {
    useLrcStore.setState({
      doc: {
        ...defaultDocument(),
        lines: [
          { id: "line-1", timestamp: 10, text: "fast lyric" },
          { id: "line-2", timestamp: 10.13, text: "next lyric" },
        ],
      },
      activeLineId: "line-1",
      currentTime: 10.06,
    });

    const { lane } = setup();
    const labels = [{ textContent: formatTimestamp(Number(lane.dataset.start)) }, { textContent: formatTimestamp(Number(lane.dataset.end)) }];
    const start = parseTimestampInput(labels[0].textContent ?? "");
    const end = parseTimestampInput(labels[1].textContent ?? "");

    expect(start).not.toBeNull();
    expect(end).not.toBeNull();
    expect((end as number) - (start as number)).toBeGreaterThanOrEqual(1.99);
  });

  it("keeps the minimum window inside the track near its start and end", () => {
    const cases = [
      { start: 0.1, end: 0.2, expectedStart: 0, expectedEnd: 2 },
      { start: 99.8, end: 99.9, expectedStart: 98, expectedEnd: 100 },
    ];

    for (const [index, item] of cases.entries()) {
      cleanup();
      useLrcStore.setState({
        doc: {
          ...defaultDocument(),
          lines: [
            { id: "line-1", timestamp: item.start, text: "fast lyric" },
            { id: "line-2", timestamp: item.end, text: "next lyric" },
          ],
        },
        activeLineId: "line-1",
        currentTime: (item.start + item.end) / 2,
      });
      const { lane } = setup();
      const labels = [{ textContent: formatTimestamp(Number(lane.dataset.start)) }, { textContent: formatTimestamp(Number(lane.dataset.end)) }];

      expect(parseTimestampInput(labels[0].textContent ?? ""), `case ${index} start`).toBeCloseTo(item.expectedStart, 1);
      expect(parseTimestampInput(labels[1].textContent ?? ""), `case ${index} end`).toBeCloseTo(item.expectedEnd, 1);
    }
  });

  it("preserves a quarter-second view at 8x zoom for a short lyric interval", () => {
    useLrcStore.setState({
      doc: {
        ...defaultDocument(),
        lines: [
          { id: "line-1", timestamp: 10, text: "fast lyric" },
          { id: "line-2", timestamp: 10.13, text: "next lyric" },
        ],
      },
      activeLineId: "line-1",
      currentTime: 10.06,
    });
    const { lane, container } = setup();

    const zoomIn = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "+")!;
    fireEvent.click(zoomIn);
    fireEvent.click(zoomIn);
    fireEvent.click(zoomIn);

    const labels = [{ textContent: formatTimestamp(Number(lane.dataset.start)) }, { textContent: formatTimestamp(Number(lane.dataset.end)) }];
    const start = parseTimestampInput(labels[0].textContent ?? "");
    const end = parseTimestampInput(labels[1].textContent ?? "");
    expect((end as number) - (start as number)).toBeGreaterThanOrEqual(0.24);
  });

  it("continuously centers playback in a zoomed viewport across lyric boundaries", () => {
    useLrcStore.setState({ isPlaying: true });
    const { lane, container, playhead } = setup();
    fireEvent.click(Array.from(container.querySelectorAll("button")).find(b => b.textContent === "+")!);
    expect(Number(lane.dataset.start)).toBe(10);
    act(() => useLrcStore.setState({ currentTime: 12.5 }));
    expect(Number(lane.dataset.start)).toBe(10.5);
    expect(playhead.style.left).toBe("50%");
    act(() => useLrcStore.setState({ currentTime: 13.5 }));
    expect(Number(lane.dataset.start)).toBeCloseTo(11.5);
    act(() => useLrcStore.setState({ currentTime: 25 }));
    expect(Number(lane.dataset.start)).toBe(23);
    expect(playhead.style.left).toBe("50%");
  });

  it("moves the playhead from left to center, scrolls the waveform, then moves it to the right", () => {
    useLrcStore.setState({ isPlaying: true, currentTime: 0 });
    const { lane, playhead } = setup();
    const cases = [
      { time: 0, start: 0, end: 8, position: 0 },
      { time: 2, start: 0, end: 8, position: 25 },
      { time: 4, start: 0, end: 8, position: 50 },
      { time: 12, start: 8, end: 16, position: 50 },
      { time: 50, start: 46, end: 54, position: 50 },
      { time: 96, start: 92, end: 100, position: 50 },
      { time: 98, start: 92, end: 100, position: 75 },
      { time: 100, start: 92, end: 100, position: 100 },
      { time: 10, start: 6, end: 14, position: 50 },
    ];
    for (const item of cases) {
      act(() => useLrcStore.setState({ currentTime: item.time }));
      expect(Number(lane.dataset.start), `time ${item.time}`).toBe(item.start);
      expect(Number(lane.dataset.end), `time ${item.time}`).toBe(item.end);
      expect(parseFloat(playhead.style.left), `time ${item.time}`).toBe(item.position);
      if (item.position === 100) {
        expect(playhead.style.transform, `visible endpoint at ${item.time}`).toBe(`translateX(-${item.position}%)`);
      }
    }
  });

  it("keeps a track shorter than the minimum window fully visible", () => {
    useLrcStore.setState({
      duration: 0.5, currentTime: 0, isPlaying: true,
      doc: { ...defaultDocument(), lines: [{ id: "line-1", timestamp: 0, text: "short" }] },
    });
    const { lane, playhead } = setup();
    for (const [time, position] of [[0, 0], [0.25, 50], [0.5, 100]]) {
      act(() => useLrcStore.setState({ currentTime: time }));
      expect(Number(lane.dataset.start)).toBe(0);
      expect(Number(lane.dataset.end)).toBe(0.5);
      expect(parseFloat(playhead.style.left)).toBe(position);
    }
  });

  it("keeps tracking without an end boundary before duration is known", () => {
    useLrcStore.setState({ duration: 0, currentTime: 50, isPlaying: true });
    const { lane, playhead } = setup();
    expect(Number(lane.dataset.start)).toBe(46);
    expect(Number(lane.dataset.end)).toBe(54);
    expect(playhead.style.left).toBe("50%");
  });

  it.each([
    { input: "click", startX: 75, endX: 75 },
    { input: "drag", startX: 20, endX: 75 },
  ])("keeps playback following disabled after a waveform $input seek", ({ startX, endX }) => {
    useLrcStore.setState({ isPlaying: true });
    const { lane, playhead, getByRole } = setup();
    const followButton = getByRole("button", { name: /재생 위치 따라가기|Follow playback/ });

    fireEvent.click(followButton);
    expect(followButton.getAttribute("aria-pressed")).toBe("false");
    fireEvent.pointerDown(lane, { pointerId: 9, button: 0, clientX: startX });
    fireEvent.pointerUp(window, { pointerId: 9, button: 0, clientX: endX });
    expect(seekSpy).toHaveBeenCalledWith(14);

    act(() => useLrcStore.setState({ currentTime: 14 }));
    expect(followButton.getAttribute("aria-pressed")).toBe("false");
    expect(Number(lane.dataset.start)).toBe(10);
    act(() => useLrcStore.setState({ currentTime: 14.5 }));
    expect(Number(lane.dataset.start)).toBe(10);

    fireEvent.click(followButton);
    expect(followButton.getAttribute("aria-pressed")).toBe("true");
    expect(Number(lane.dataset.start)).toBe(10.5);
    expect(playhead.style.left).toBe("50%");
  });

  it("pans a zoomed viewport without seeking or changing glyph timing", () => {
    const { lane, container, getByRole } = setup();
    fireEvent.click(Array.from(container.querySelectorAll("button")).find(b => b.textContent === "+")!);
    fireEvent.click(getByRole("button", { name: /다음 시간 구간|Next time window/ }));
    expect(Number(lane.dataset.start)).toBe(12);
    expect(seekSpy).not.toHaveBeenCalled();
    expect(useLrcStore.getState()._history).toHaveLength(0);
  });

  it("keeps manual pan detached during playback until explicitly following again", () => {
    useLrcStore.setState({ isPlaying: true, doc: { ...defaultDocument(), lines: [
      { id: "line-1", text: "first", timestamp: 10 }, { id: "line-2", text: "next", timestamp: 30 },
    ] } });
    const { lane, container, getByRole } = setup();
    const zoomIn = Array.from(container.querySelectorAll("button")).find(b => b.textContent === "+")!;
    fireEvent.click(zoomIn); fireEvent.click(zoomIn); fireEvent.click(zoomIn);
    const next = getByRole("button", { name: /다음 시간 구간|Next time window/ });
    fireEvent.click(next); fireEvent.click(next);
    const start = Number(lane.dataset.start);
    act(() => useLrcStore.setState({ currentTime: 12.01 }));
    expect(Number(lane.dataset.start)).toBe(start);
    fireEvent.click(getByRole("button", { name: /재생 위치 따라가기|Follow playback/ }));
    expect(Number(lane.dataset.start)).toBeCloseTo(10.76);
  });

  it("toggles the current line repeat without starting playback and clears it on line change", () => {
    useLrcStore.setState({ doc: { ...defaultDocument(), lines: [
      { id: "line-1", text: "first", timestamp: 10 }, { id: "line-2", text: "next", timestamp: 20 },
    ] }});
    const { getByRole } = setup();
    const repeat = getByRole("button", { name: /줄 반복|Repeat line/ });
    fireEvent.click(repeat);
    expect(repeat.getAttribute("aria-pressed")).toBe("true");
    expect(useLrcStore.getState().loopLineId).toBe("line-1");
    expect(seekSpy).toHaveBeenCalledWith(10);
    expect(useLrcStore.getState().isPlaying).toBe(false);
    fireEvent.click(repeat);
    expect(useLrcStore.getState().loopLineId).toBeNull();
    fireEvent.click(repeat);
    act(() => useLrcStore.setState({ activeLineId: "line-2" }));
    expect(useLrcStore.getState().loopLineId).toBeNull();
  });

  it("disables line repeat when the line has no timestamp or the source is external", () => {
    useLrcStore.setState({ doc: { ...defaultDocument(), lines: [{ id: "line-1", text: "first", timestamp: null }] } });
    const { getByRole } = setup();
    expect((getByRole("button", { name: /줄 반복|Repeat line/ }) as HTMLButtonElement).disabled).toBe(true);
    act(() => {
      useLrcStore.setState({ doc: { ...defaultDocument(), lines: [{ id: "line-1", text: "first", timestamp: 10 }] } });
      useSettingsStore.setState({ deviceMode: true });
    });
    expect((getByRole("button", { name: /줄 반복|Repeat line/ }) as HTMLButtonElement).disabled).toBe(true);
  });

  it("previews drag movement without changing playback time, then seeks once to the release position", () => {
    const { lane, playhead } = setup();

    fireEvent.pointerDown(lane, { pointerId: 1, button: 0, clientX: 20 });
    fireEvent.pointerMove(window, { pointerId: 1, clientX: 75 });
    expect(seekSpy).not.toHaveBeenCalled();
    expect(useLrcStore.getState().currentTime).toBe(12);

    act(() => rafCallbacks.splice(0).forEach((callback) => callback(0)));
    expect(playhead.style.left).toBe("75%");
    expect(seekSpy).not.toHaveBeenCalled();

    fireEvent.pointerUp(window, { pointerId: 1, button: 0, clientX: 80 });
    expect(seekSpy).toHaveBeenCalledTimes(1);
    expect(seekSpy).toHaveBeenCalledWith(14.4);
    expect(useLrcStore.getState().currentTime).toBe(12);
  });

  it("does not seek when the drag is cancelled or the component unmounts", () => {
    const { lane, unmount } = setup();

    fireEvent.pointerDown(lane, { pointerId: 2, button: 0, clientX: 20 });
    fireEvent.pointerMove(window, { pointerId: 2, clientX: 70 });
    fireEvent.pointerCancel(window, { pointerId: 2 });
    expect(seekSpy).not.toHaveBeenCalled();

    fireEvent.pointerDown(lane, { pointerId: 3, button: 0, clientX: 20 });
    unmount();
    fireEvent.pointerUp(window, { pointerId: 3, button: 0, clientX: 70 });
    expect(seekSpy).not.toHaveBeenCalled();
  });

  it("cancels an active drag when the audio path changes", () => {
    const { lane } = setup();

    fireEvent.pointerDown(lane, { pointerId: 4, button: 0, clientX: 20 });
    fireEvent.pointerMove(window, { pointerId: 4, clientX: 80 });
    act(() => useLrcStore.setState({ audioPath: "/music/other.mp3" }));
    fireEvent.pointerUp(window, { pointerId: 4, button: 0, clientX: 80 });

    expect(seekSpy).not.toHaveBeenCalled();
  });

  it("cancels an active drag if playback switches from local audio to Spotify", () => {
    const serviceSeekSpy = vi.spyOn(serviceControls, "seekTo").mockImplementation(() => {});
    const { lane } = setup();

    fireEvent.pointerDown(lane, { pointerId: 5, button: 0, clientX: 20 });
    fireEvent.pointerMove(window, { pointerId: 5, clientX: 80 });
    act(() => {
      useSettingsStore.setState({ spotifyMode: true });
      useServiceStore.setState({ isLoggedIn: true });
    });
    fireEvent.pointerUp(window, { pointerId: 5, button: 0, clientX: 80 });

    expect(seekSpy).not.toHaveBeenCalled();
    expect(serviceSeekSpy).not.toHaveBeenCalled();
  });

  it("cancels an active Spotify lane drag when the track changes at the same duration", () => {
    useSettingsStore.setState({ spotifyMode: true });
    useServiceStore.setState({ isLoggedIn: true, trackUri: "spotify:track:first" });
    const serviceSeekSpy = vi.spyOn(serviceControls, "seekTo").mockImplementation(() => {});
    const { lane } = setup();

    fireEvent.pointerDown(lane, { pointerId: 6, button: 0, clientX: 20 });
    fireEvent.pointerMove(window, { pointerId: 6, clientX: 80 });
    act(() => useServiceStore.setState({ trackUri: "spotify:track:second" }));
    fireEvent.pointerUp(window, { pointerId: 6, button: 0, clientX: 80 });

    expect(serviceSeekSpy).not.toHaveBeenCalled();
  });

  it("uses the frozen displayed window for a new drag while a previous seek is pending", () => {
    const { container, lane } = setup();
    fireEvent.click(Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "+")!);

    fireEvent.pointerDown(lane, { pointerId: 7, button: 0, clientX: 20 });
    act(() => useLrcStore.setState({ currentTime: 20 }));
    fireEvent.pointerUp(window, { pointerId: 7, button: 0, clientX: 80 });
    expect(seekSpy).toHaveBeenCalledTimes(1);

    fireEvent.pointerDown(lane, { pointerId: 8, button: 0, clientX: 50 });
    fireEvent.pointerUp(window, { pointerId: 8, button: 0, clientX: 50 });

    expect(seekSpy).toHaveBeenLastCalledWith(12);
  });
});

it('applies waveform view settings without seeking or editing lyrics', () => {
  useLrcStore.setState({ doc: { ...defaultDocument(), lines: [{ id: 'line-1', timestamp: 10, text: 'ab', syllables: [{ text: 'a', time: 10 }, { text: 'b', time: 12 }] }] } });
  const before = useLrcStore.getState().doc;
  const { getByRole, lane, container } = setup();
  fireEvent.click(getByRole('button', { name: /파형 보기|Waveform view/ }));
  fireEvent.change(getByRole('slider', { name: /파형 높이|Waveform height/ }), { target: { value: '240' } });
  expect(lane.style.height).toBe('240px');
  const markers = container.querySelector('[data-testid="glyph-marker-lane"]')!;
  expect(markers.querySelector('button')).not.toBeNull();
  fireEvent.click(getByRole('checkbox', { name: /글자 마커 표시|Show glyph markers/ }));
  expect(markers.querySelector('button')).toBeNull();
  expect(useLrcStore.getState().doc).toBe(before);
  expect(seekSpy).not.toHaveBeenCalled();
});

it('closes waveform view options with Escape and returns focus to its trigger', () => {
  const { getByRole, queryByRole } = setup();
  const trigger = getByRole('button', { name: /파형 보기|Waveform view/ });
  fireEvent.click(trigger);
  fireEvent.keyDown(document, { key: 'Escape', code: 'Escape' });
  expect(queryByRole('slider')).toBeNull();
  expect(document.activeElement).toBe(trigger);
});

it('keeps the viewport scale when stamping changes the current line start', () => {
  useLrcStore.setState({ doc: { ...defaultDocument(), lines: [
    { id: 'line-1', timestamp: 10, text: 'ab' }, { id: 'line-2', timestamp: 20, text: 'next' },
  ] } });
  const { lane, getByRole } = setup();
  const span = Number(lane.dataset.end) - Number(lane.dataset.start);
  fireEvent.click(getByRole('button', { name: useI18nStore.getState().t.charSync.stampHint }));
  expect(useLrcStore.getState().doc.lines[0].timestamp).toBe(12);
  expect(Number(lane.dataset.end) - Number(lane.dataset.start)).toBeCloseTo(span);
});

it.each(['replay', 'nudge'])('reattaches following after manual pan and %s', action => {
  useLrcStore.setState({ doc: { ...defaultDocument(), lines: [
    { id: 'line-1', timestamp: 10, text: 'ab', syllables: [{ text: 'a', time: 10 }, { text: 'b', time: 12 }] },
    { id: 'line-2', timestamp: 20, text: 'next' },
  ] } });
  const { lane, getByRole } = setup();
  fireEvent.click(getByRole('button', { name: /다음 시간 구간|Next time window/ }));
  if (action === 'replay') fireEvent.click(getByRole('button', { name: /이 줄 재생|Replay line|Play line/ }));
  else fireEvent.keyDown(window, { code: 'ArrowRight', shiftKey: true });
  expect(getByRole('button', { name: /재생 위치 따라가기|Follow playback/ }).getAttribute('aria-pressed')).toBe('true');
  act(() => useLrcStore.setState({ currentTime: 40 }));
  expect(Number(lane.dataset.start)).toBeCloseTo(35);
});

it('paints vertically across wrapped glyphs in a single undo entry', () => {
  const { container } = setup();
  const first = container.querySelector('[data-glyph="0"]')!;
  const second = container.querySelector('[data-glyph="1"]')!;
  const point = vi.fn(() => second);
  Object.defineProperty(document, 'elementFromPoint', { configurable: true, value: point });
  fireEvent.mouseDown(first, { button: 0, clientX: 10, clientY: 10 });
  fireEvent.mouseMove(window, { buttons: 1, clientX: 10, clientY: 30 });
  fireEvent.mouseMove(window, { buttons: 1, clientX: 10, clientY: 40 });
  fireEvent.mouseUp(window);
  expect(useLrcStore.getState().doc.lines[0].syllables?.slice(0, 2).map(s => s.time)).toEqual([12, 12]);
  expect(useLrcStore.getState()._history).toHaveLength(1);
});

it.each(["window blur", "buttons=0 movement"])("cancels an unfinished glyph gesture after %s", (reason) => {
  const { container } = setup();
  const first = container.querySelector('[data-glyph="0"]')!;
  const wasDirty = useLrcStore.getState().isDirty;
  fireEvent.mouseDown(first, { button: 0, buttons: 1, clientX: 10, clientY: 10 });
  if (reason === "buttons=0 movement") {
    fireEvent.mouseMove(window, { buttons: 0, clientX: 20, clientY: 20 });
  } else {
    fireEvent.blur(window);
    fireEvent.mouseMove(window, { buttons: 1, clientX: 20, clientY: 20 });
  }
  expect(useLrcStore.getState().doc.lines[0].syllables).toBeUndefined();
  expect(useLrcStore.getState()._history).toHaveLength(0);
  expect(useLrcStore.getState().isDirty).toBe(wasDirty);
});

it.each(["document", "audio", "sync unit", "sync mode", "playback source", "modal"])(
  "cancels a glyph gesture when its %s context changes",
  (context) => {
    const { container } = setup();
    const first = container.querySelector('[data-glyph="0"]')!;
    const wasDirty = useLrcStore.getState().isDirty;
    fireEvent.mouseDown(first, { button: 0, buttons: 1, clientX: 10, clientY: 10 });
    act(() => {
      if (context === "document") {
        useLrcStore.setState({
          _documentSession: useLrcStore.getState()._documentSession + 1,
          doc: { ...defaultDocument(), lines: [{ id: "line-1", timestamp: 10, text: "hello" }] },
        });
      } else if (context === "audio") {
        useLrcStore.setState({ _audioSelection: useLrcStore.getState()._audioSelection + 1 });
      } else if (context === "sync unit") {
        useLrcStore.getState().setSyncUnit("word");
      } else if (context === "sync mode") {
        useLrcStore.getState().setSyncMode("line");
      } else if (context === "playback source") {
        useSettingsStore.setState({ deviceMode: true });
      } else {
        const modal = document.createElement("div");
        modal.className = "fixed inset-0";
        modal.dataset.testModal = "true";
        document.body.append(modal);
      }
    });
    fireEvent.mouseMove(window, { buttons: 1, clientX: 30, clientY: 30 });
    expect(useLrcStore.getState().doc.lines[0].syllables).toBeUndefined();
    expect(useLrcStore.getState()._history).toHaveLength(0);
    expect(useLrcStore.getState().isDirty).toBe(wasDirty);
    document.querySelector('[data-test-modal="true"]')?.remove();
  },
);

it('ignores stamp and nudge shortcuts during IME composition', () => {
  setup();
  fireEvent.keyDown(window, { code: 'Space', isComposing: true });
  expect(useLrcStore.getState().doc.lines[0].syllables).toBeUndefined();
  fireEvent.keyDown(window, { code: 'Space', keyCode: 229 });
  expect(useLrcStore.getState()._history).toHaveLength(0);
});

it('clears line repeat when the local audio path changes', () => {
  const { getByRole } = setup();
  fireEvent.click(getByRole('button', { name: /줄 반복|Repeat line/ }));
  expect(useLrcStore.getState().loopLineId).toBe('line-1');
  act(() => useLrcStore.setState({ audioPath: '/music/replacement.mp3' }));
  expect(useLrcStore.getState().loopLineId).toBeNull();
});

it("opens shortcut settings from the header without a bottom help or overflow menu", () => {
  const onOpenShortcuts = vi.fn();
  const view = render(<CharSyncView onOpenShortcuts={onOpenShortcuts} />);
  fireEvent.click(view.getByRole("button", {name:useI18nStore.getState().t.charSync.shortcuts}));
  expect(onOpenShortcuts).toHaveBeenCalledOnce();
  expect(view.container.querySelector("details")).toBeNull();
  expect(view.getByRole("button",{name:useI18nStore.getState().t.charSync.clearTimingButton})).toBeTruthy();
});


it("blocks glyph shortcuts behind the actual clear confirmation dialog", () => {
  useLrcStore.setState({doc:{...defaultDocument(),lines:[{id:"line-1",timestamp:10,text:"ab",syllables:[{text:"a",time:10},{text:"b",time:11}]}]}});
  const {getByRole} = setup();
  const before = useLrcStore.getState();
  fireEvent.click(getByRole("button",{name:useI18nStore.getState().t.charSync.clearTimingButton}));
  expect(getByRole("dialog")).toBeTruthy();
  for (const code of ["Space","Backspace","ArrowLeft","ArrowRight"]) fireEvent.keyDown(window,{code});
  expect(useLrcStore.getState().doc).toBe(before.doc);
  expect(useLrcStore.getState().activeSyllableIndex).toBe(before.activeSyllableIndex);
  expect(useLrcStore.getState()._history).toEqual(before._history);
});
