// @vitest-environment jsdom
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { render, screen, cleanup, fireEvent, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

// zustand persist(useSettingsStore/useI18nStore/useLrcStore 등)용 최소 localStorage 폴리필
if (typeof globalThis.localStorage === "undefined") {
  const m = new Map<string, string>();
  globalThis.localStorage = {
    getItem: (k: string) => m.get(k) ?? null,
    setItem: (k: string, v: string) => void m.set(k, String(v)),
    removeItem: (k: string) => void m.delete(k),
    clear: () => m.clear(),
    key: () => null,
    length: 0,
  } as Storage;
}

// App.tsx가 마운트 시 건드리는 Tauri API 전부 스텁 — 이 테스트는 드래그앤드롭 충돌
// 해소 로직(App.tsx 자체)만 검증하므로, 실제 IPC/OS 연동은 필요 없음.
const { dragDropHandler, dialogOpen } = vi.hoisted(() => ({
  dragDropHandler: { current: null as ((e: unknown) => void) | null },
  dialogOpen: vi.fn(),
}));
vi.mock("@tauri-apps/api/webview", () => ({
  getCurrentWebview: () => ({
    onDragDropEvent: (cb: (e: unknown) => void) => {
      dragDropHandler.current = cb;
      return Promise.resolve(() => {});
    },
  }),
}));
vi.mock("@tauri-apps/api/event", () => ({ listen: vi.fn(() => Promise.resolve(() => {})) }));
vi.mock("@tauri-apps/api/core", () => ({ invoke: vi.fn(() => Promise.resolve(undefined)) }));
vi.mock("@tauri-apps/plugin-dialog", () => ({ open: dialogOpen, save: vi.fn() }));
vi.mock("@tauri-apps/plugin-opener", () => ({ openUrl: vi.fn() }));

// 이 테스트가 검증하는 건 App 자신의 드롭 충돌 판단/모달 로직뿐이므로, 나머지 화면을
// 채우는 무거운 자식 컴포넌트(wavesurfer 등 자체 의존성이 큰)는 전부 스텁으로 대체.
vi.mock("./components/AudioPlayer/AudioPlayer", () => ({ AudioPlayer: () => null }));
vi.mock("./components/MetaEditor/MetaEditor", () => ({ MetaEditor: () => null }));
vi.mock("./components/LrcEditor/LrcEditor", () => ({ LrcEditor: () => null }));
vi.mock("./components/Service/ModeSelectButton", () => ({ ModeSelectButton: () => null }));
vi.mock("./components/AppShell/RecentFilesMenu", () => ({ RecentFilesMenu: () => null }));
vi.mock("./components/AppShell/LangDropdown", () => ({ LangDropdown: () => null }));
vi.mock("./components/AppShell/HistoryPanel", () => ({ HistoryPanel: () => null }));
vi.mock("./components/Update/UpdateModal", () => ({ UpdateModal: () => null }));
vi.mock("./hooks/useMacMenu", () => ({ useMacMenu: () => {} }));

import App from "./App";
import { useLrcStore } from "./stores/useLrcStore";
import { defaultDocument } from "./types/lrc";
import { installMemoryLocalStorage } from "./test/memoryLocalStorage";

const resetLrc = (overrides: Partial<ReturnType<typeof useLrcStore.getState>> = {}) => {
  useLrcStore.setState({
    doc: defaultDocument(),
    audioPath: null,
    lrcPath: null,
    isDirty: false,
    syncMode: "line",
    _history: [],
    _future: [],
    ...overrides,
  });
};

describe("App — drag-and-drop conflict resolution", () => {
  beforeEach(() => {
    resetLrc();
    dragDropHandler.current = null;
    dialogOpen.mockReset();
  });

  afterEach(() => {
    cleanup();
    vi.restoreAllMocks();
  });

  const drop = (paths: string[]) => {
    dragDropHandler.current?.({ payload: { type: "drop", paths } });
  };

  it("opens dropped files directly when nothing is loaded yet (no conflict)", async () => {
    const setAudioPathSpy = vi.spyOn(useLrcStore.getState(), "setAudioPath").mockImplementation(() => {});
    render(<App />);

    drop(["/music/song.mp3"]);

    // 충돌이 없으므로 확인 모달 없이 바로 적용됨
    expect(screen.queryByText("파일 열기")).toBeNull();
    expect(setAudioPathSpy).toHaveBeenCalledWith("/music/song.mp3");
  });

  it("asks for confirmation when dropping audio while audio is already loaded, and applies only on confirm", async () => {
    resetLrc({ audioPath: "/music/old.mp3" });
    const setAudioPathSpy = vi.spyOn(useLrcStore.getState(), "setAudioPath").mockImplementation(() => {});
    const user = userEvent.setup();
    render(<App />);

    drop(["/music/new.mp3"]);

    expect(await screen.findByText("작업 중인 오디오가 있습니다. 새 오디오로 교체하시겠습니까?")).toBeTruthy();
    expect(setAudioPathSpy).not.toHaveBeenCalled();

    await user.click(screen.getByText("교체"));
    expect(setAudioPathSpy).toHaveBeenCalledWith("/music/new.mp3");
  });

  it("dismisses without applying when the conflict is cancelled", async () => {
    resetLrc({ audioPath: "/music/old.mp3" });
    const setAudioPathSpy = vi.spyOn(useLrcStore.getState(), "setAudioPath").mockImplementation(() => {});
    const user = userEvent.setup();
    render(<App />);

    drop(["/music/new.mp3"]);
    expect(await screen.findByText("작업 중인 오디오가 있습니다. 새 오디오로 교체하시겠습니까?")).toBeTruthy();

    await user.click(screen.getByText("취소"));
    expect(setAudioPathSpy).not.toHaveBeenCalled();
    expect(screen.queryByText("작업 중인 오디오가 있습니다. 새 오디오로 교체하시겠습니까?")).toBeNull();
  });

  it("uses the combined message when both audio and lyrics are already loaded/dirty", async () => {
    resetLrc({ audioPath: "/music/old.mp3", lrcPath: "/music/old.lrc", isDirty: true });
    vi.spyOn(useLrcStore.getState(), "setAudioPath").mockImplementation(() => {});
    vi.spyOn(useLrcStore.getState(), "loadLyricsPath").mockResolvedValue(undefined as never);
    render(<App />);

    drop(["/music/new.mp3", "/music/new.lrc"]);

    expect(
      await screen.findByText("작업 중인 오디오·가사가 있습니다. 저장하지 않은 변경 사항은 사라집니다. 교체하시겠습니까?")
    ).toBeTruthy();
  });

  it("ignores dropped files with unsupported extensions", async () => {
    const setAudioPathSpy = vi.spyOn(useLrcStore.getState(), "setAudioPath").mockImplementation(() => {});
    render(<App />);

    drop(["/documents/readme.txt"]);

    expect(setAudioPathSpy).not.toHaveBeenCalled();
    expect(screen.queryByText("파일 열기")).toBeNull();
  });

  it("confirms before File > Open replaces unsaved lyrics", async () => {
    resetLrc({ isDirty: true, lrcPath: "/music/old.lrc" });
    dialogOpen.mockResolvedValue("/music/new.lrc");
    const loadLyricsPathSpy = vi.spyOn(useLrcStore.getState(), "loadLyricsPath").mockResolvedValue(undefined);
    const user = userEvent.setup();
    render(<App />);

    await user.click(screen.getByRole("button", { name: "가사 열기" }));
    expect(await screen.findByText("작업 중인 가사가 있습니다. 저장하지 않은 변경 사항은 사라집니다. 교체하시겠습니까?")).toBeTruthy();
    expect(loadLyricsPathSpy).not.toHaveBeenCalled();

    await user.click(screen.getByText("교체"));
    expect(loadLyricsPathSpy).toHaveBeenCalledWith("/music/new.lrc", undefined);
  });

  it("does not intercept Space on a focused button as a stamp shortcut", async () => {
    const stampSpy = vi.spyOn(useLrcStore.getState(), "stampAndAdvance");
    render(<><App /><button>focus target</button></>);

    const button = screen.getByRole("button", { name: "focus target" });
    button.focus();
    const event = new KeyboardEvent("keydown", { code: "Space", key: " ", bubbles: true, cancelable: true });
    button.dispatchEvent(event);

    expect(event.defaultPrevented).toBe(false);
    expect(stampSpy).not.toHaveBeenCalled();
  });

  it("does not move to the previous line when Backspace is pressed on a select", async () => {
    const previousSpy = vi.spyOn(useLrcStore.getState(), "goToPreviousLine");
    render(<><App /><select aria-label="focus target"><option>one</option></select></>);

    const select = screen.getByRole("combobox", { name: "focus target" });
    select.focus();
    const event = new KeyboardEvent("keydown", { code: "Backspace", key: "Backspace", bubbles: true, cancelable: true });
    select.dispatchEvent(event);

    expect(event.defaultPrevented).toBe(false);
    expect(previousSpy).not.toHaveBeenCalled();
  });

  it("keeps Space stamping available from the non-interactive editor surface", async () => {
    const stampSpy = vi.spyOn(useLrcStore.getState(), "stampAndAdvance");
    render(<><App /><div data-testid="editor-surface" tabIndex={0}>editor</div></>);

    const surface = screen.getByTestId("editor-surface");
    surface.focus();
    fireEvent.keyDown(surface, { code: "Space", key: " " });

    expect(stampSpy).toHaveBeenCalledTimes(1);
  });
});


import { saveRecoverySnapshot, loadRecoverySnapshot } from "./utils/recovery";
import { useSettingsStore } from "./stores/useSettingsStore";
import { useI18nStore } from "./stores/useI18nStore";

// These exercise the actual startup effects and persisted bytes, not a mocked recovery hook.
describe("App — recovery lifecycle", () => {
  beforeEach(() => {
    localStorage.clear();
    resetLrc();
    useSettingsStore.setState({ autoCheckUpdate: false, autoSave: false, spotifyMode: false, deviceMode: false });
  });
  afterEach(() => { cleanup(); vi.restoreAllMocks(); vi.useRealTimers(); });
  const snapshot = (withLines = true) => {
    const doc = defaultDocument();
    doc.metadata.title = "Recovered title";
    if (withLines) doc.lines = [{ id: "1", text: "Recovered lyric", timestamp: 1 }];
    expect(saveRecoverySnapshot(doc, null, null)).toBe(true);
    return doc;
  };
  it("retains persisted recovery while awaiting a decision across remounts", () => {
    const doc = snapshot();
    const first = render(<App />);
    expect(loadRecoverySnapshot()?.doc).toEqual(doc);
    first.unmount();
    render(<App />);
    expect(screen.getByText(useI18nStore.getState().t.recovery.title)).toBeTruthy();
    expect(loadRecoverySnapshot()?.doc).toEqual(doc);
  });
  it("offers metadata-only recovery", () => {
    const doc = snapshot(false);
    render(<App />);
    expect(screen.getByText(useI18nStore.getState().t.recovery.title)).toBeTruthy();
    expect(loadRecoverySnapshot()?.doc).toEqual(doc);
  });
  it("retains a durable copy immediately after restoring", () => {
    const doc = snapshot();
    render(<App />);
    fireEvent.click(screen.getByText(useI18nStore.getState().t.recovery.restore));
    expect(useLrcStore.getState().doc.metadata.title).toBe(doc.metadata.title);
    expect(useLrcStore.getState().isDirty).toBe(true);
    expect(loadRecoverySnapshot()?.doc.metadata.title).toBe(doc.metadata.title);
  });
  it("removes the expected snapshot on explicit discard", () => {
    snapshot();
    render(<App />);
    fireEvent.click(screen.getByText(useI18nStore.getState().t.recovery.discard));
    expect(loadRecoverySnapshot()).toBeNull();
  });
  it("keeps a recovery checkpoint during continuous edits", () => {
    vi.useFakeTimers();
    render(<App />);
    act(() => useLrcStore.getState().loadFromRawText("[00:01.00]start"));
    const id = useLrcStore.getState().doc.lines[0].id;
    for (let i = 1; i <= 6; i++) {
      act(() => { useLrcStore.getState().updateLine(id, { text: `edit ${i}` }); vi.advanceTimersByTime(1000); });
    }
    expect(loadRecoverySnapshot()?.doc.lines[0].text).toBe("edit 5");
  });
  it("reports a failed recovery write without destroying the editor", () => {
    const { storage, restore } = installMemoryLocalStorage();
    const originalSetItem = storage.setItem.bind(storage);
    const setItemSpy = vi.spyOn(storage, "setItem").mockImplementation((key, value) => {
      if (key === "lyrical-sync-recovery") throw new Error("quota exceeded");
      originalSetItem(key, value);
    });
    try {
      render(<App />);
      act(() => useLrcStore.getState().loadFromRawText("[00:01.00]not saved"));
      fireEvent(window, new Event("pagehide"));
      expect(setItemSpy).toHaveBeenCalledWith("lyrical-sync-recovery", expect.any(String));
      expect(screen.getByText(useI18nStore.getState().t.toast.recoveryFailed)).toBeTruthy();
      expect(useLrcStore.getState().doc.lines[0].text).toBe("not saved");
    } finally {
      restore();
    }
  });
  it("flushes the latest edits on pagehide before the debounce fires", () => {
    render(<App />);
    // Direct store action is the same edit boundary used by editor components.
    fireEvent(window, new Event("pagehide"));
    useLrcStore.getState().loadFromRawText("[00:01.00]latest edit");
    fireEvent(window, new Event("pagehide"));
    expect(loadRecoverySnapshot()?.doc.lines[0].text).toBe("latest edit");
  });
});


import { invoke } from "@tauri-apps/api/core";
describe("App — paired drop transactions", () => {
  beforeEach(() => {
    localStorage.clear();
    resetLrc({ audioPath: "/old.mp3", lrcPath: "/old.lrc" });
    vi.mocked(invoke).mockReset();
    useSettingsStore.setState({ autoCheckUpdate: false, spotifyMode: false, deviceMode: false });
  });
  afterEach(() => { cleanup(); vi.restoreAllMocks(); });
  it("retains the old audio if the confirmed replacement lyrics fail to read", async () => {
    vi.mocked(invoke).mockImplementation(command => command === "read_lrc_file"
      ? Promise.reject(new Error("unreadable")) : Promise.resolve(undefined));
    render(<App />);
    act(() => dragDropHandler.current?.({ payload: { type: "drop", paths: ["/new.mp3", "/new.lrc"] } }));
    await userEvent.setup().click(screen.getByText(useI18nStore.getState().t.drop.replaceOk));
    expect(await screen.findByText(useI18nStore.getState().t.toast.openFailed)).toBeTruthy();
    expect(useLrcStore.getState().audioPath).toBe("/old.mp3");
    expect(useLrcStore.getState().lrcPath).toBe("/old.lrc");
  });
});

it("shows a recoverable error without losing the current document", () => {
  localStorage.clear(); resetLrc();
  useSettingsStore.setState({ autoCheckUpdate: false, spotifyMode: false, deviceMode: false });
  const view = render(<App />);
  act(() => useLrcStore.getState().loadFromRawText("[00:01.00]current edit"));
  fireEvent(window, new CustomEvent("lyrical-runtime-error", { detail: "background error" }));
  expect(screen.getByText(useI18nStore.getState().t.toast.runtimeFailed)).toBeTruthy();
  expect(useLrcStore.getState().doc.lines[0].text).toBe("current edit");
  expect(useLrcStore.getState().isDirty).toBe(true);
  view.unmount();
});
