use reqwest::Client;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::io::Write;
use std::path::Path;
use tauri::{AppHandle, Manager, Emitter};

static OAUTH_SERVER: crate::oauth_listener::OAuthServer = crate::oauth_listener::OAuthServer::new();

fn token_path(app: &AppHandle) -> Result<std::path::PathBuf, String> {
    app.path().app_data_dir()
        .map(|d| d.join("spotify_token.dat"))
        .map_err(|e| e.to_string())
}

const KEYRING_SERVICE: &str = "Lyrical Sync";
const KEYRING_USER: &str = "spotify_refresh_token";

// `npm run tauri dev`는 재빌드마다 서명(identity)이 바뀌어 매번 키체인 접근 허가를
// 새로 물어봄 → 개발 빌드에서는 키체인을 건너뛰고 평문 파일로만 저장(배포용 release
// 빌드는 서명이 안정적이므로 키체인을 그대로 사용).
fn keyring_entry() -> Result<keyring::Entry, keyring::Error> {
    if cfg!(debug_assertions) {
        return Err(keyring::Error::NoEntry);
    }
    keyring::Entry::new(KEYRING_SERVICE, KEYRING_USER)
}

/// Returned to TypeScript via Tauri (camelCase)
#[derive(Serialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct TokenResponse {
    pub access_token: String,
    pub refresh_token: Option<String>,
    pub expires_in: u64,
}

/// Spotify API response (snake_case)
#[derive(Deserialize)]
struct SpotifyApiToken {
    access_token: String,
    refresh_token: Option<String>,
    expires_in: u64,
}

impl From<SpotifyApiToken> for TokenResponse {
    fn from(t: SpotifyApiToken) -> Self {
        TokenResponse {
            access_token: t.access_token,
            refresh_token: t.refresh_token,
            expires_in: t.expires_in,
        }
    }
}

#[tauri::command]
pub async fn exchange_spotify_token(
    code: String,
    code_verifier: String,
    client_id: String,
    redirect_uri: String,
) -> Result<TokenResponse, String> {
    let client = Client::new();
    let mut params = HashMap::new();
    params.insert("grant_type", "authorization_code");
    params.insert("code", code.as_str());
    params.insert("redirect_uri", redirect_uri.as_str());
    params.insert("client_id", client_id.as_str());
    params.insert("code_verifier", code_verifier.as_str());

    let resp = client
        .post("https://accounts.spotify.com/api/token")
        .form(&params)
        .send()
        .await
        .map_err(|e| format!("토큰 요청 실패: {e}"))?;

    if !resp.status().is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(format!("토큰 발급 실패: {text}"));
    }

    resp.json::<SpotifyApiToken>()
        .await
        .map(TokenResponse::from)
        .map_err(|e| format!("응답 파싱 실패: {e}"))
}

#[tauri::command]
pub async fn refresh_spotify_token(
    refresh_token: String,
    client_id: String,
) -> Result<TokenResponse, String> {
    let client = Client::new();
    let mut params = HashMap::new();
    params.insert("grant_type", "refresh_token");
    params.insert("refresh_token", refresh_token.as_str());
    params.insert("client_id", client_id.as_str());

    let resp = client
        .post("https://accounts.spotify.com/api/token")
        .form(&params)
        .send()
        .await
        .map_err(|e| format!("토큰 갱신 요청 실패: {e}"))?;

    if !resp.status().is_success() {
        let text = resp.text().await.unwrap_or_default();
        return Err(format!("토큰 갱신 실패: {text}"));
    }

    resp.json::<SpotifyApiToken>()
        .await
        .map(TokenResponse::from)
        .map_err(|e| format!("응답 파싱 실패: {e}"))
}

// 평문 파일 저장 (OS 키체인 사용 불가 시 폴백). unix는 0600, windows는 icacls로
// 현재 사용자 전용 ACL(상속 제거 후 재부여)을 건다.
fn save_token_file(app: &AppHandle, token: &str) -> Result<(), String> {
    let path = token_path(app)?;
    write_restricted_token_file(&path, token)
}

fn write_restricted_token_file(path: &Path, token: &str) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }

    let parent = path.parent().ok_or("토큰 경로에 부모 디렉터리가 없습니다")?;
    let mut temp = tempfile::NamedTempFile::new_in(parent)
        .map_err(|e| format!("토큰 임시 파일 생성 실패: {e}"))?;
    temp.write_all(token.as_bytes())
        .map_err(|e| format!("토큰 저장 실패: {e}"))?;
    temp.as_file().sync_all().map_err(|e| format!("토큰 저장 실패: {e}"))?;

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(temp.path(), std::fs::Permissions::from_mode(0o600))
            .map_err(|e| format!("토큰 파일 권한 설정 실패: {e}"))?;
    }
    #[cfg(windows)]
    {
        let path_str = temp.path().to_str().ok_or("토큰 경로를 Windows 형식으로 변환할 수 없습니다")?;
        let user = std::env::var("USERNAME").map_err(|e| format!("현재 Windows 사용자를 확인할 수 없습니다: {e}"))?;
        let domain = std::env::var("USERDOMAIN").unwrap_or_default();
        let identity = if domain.is_empty() { user } else { format!("{domain}\\{user}") };
        let grant_user = format!("{identity}:F");
        let output = std::process::Command::new("icacls")
            .args([path_str, "/inheritance:r", "/grant:r", grant_user.as_str(), "SYSTEM:F"])
            .output()
            .map_err(|e| format!("토큰 파일 ACL 도구 실행 실패: {e}"))?;
        if !output.status.success() {
            return Err(format!("토큰 파일 ACL 설정 실패: {}", String::from_utf8_lossy(&output.stderr).trim()));
        }
    }

    temp.persist(path).map_err(|e| format!("토큰 파일 확정 실패: {}", e.error))?;
    Ok(())
}

#[tauri::command]
pub fn save_refresh_token(token: String, app: AppHandle) -> Result<(), String> {
    // 1순위: OS 키체인(암호화 저장). 성공 시 기존 평문 파일은 제거(마이그레이션).
    if let Ok(entry) = keyring_entry() {
        if entry.set_password(&token).is_ok() {
            if let Ok(path) = token_path(&app) {
                let _ = std::fs::remove_file(path);
            }
            return Ok(());
        }
    }
    // 폴백: 0600 평문 파일
    save_token_file(&app, &token)
}

#[tauri::command]
pub fn load_refresh_token(app: AppHandle) -> Result<Option<String>, String> {
    // 1순위: 키체인
    if let Ok(entry) = keyring_entry() {
        match entry.get_password() {
            Ok(t) => {
                let trimmed = t.trim().to_string();
                return Ok(if trimmed.is_empty() { None } else { Some(trimmed) });
            }
            Err(keyring::Error::NoEntry) => {} // 키체인에 없음 → 레거시 파일 확인
            Err(_) => {}                        // 키체인 사용 불가 → 파일 폴백
        }
    }
    // 폴백/레거시: 평문 파일
    let path = token_path(&app)?;
    if !path.exists() {
        return Ok(None);
    }
    let token = std::fs::read_to_string(&path).map_err(|e| format!("토큰 읽기 실패: {e}"))?;
    let trimmed = token.trim().to_string();
    Ok(if trimmed.is_empty() { None } else { Some(trimmed) })
}

/// Replace any pending login with a bounded listener authenticated by its random state.
#[tauri::command]
pub async fn start_oauth_listener(app: AppHandle, state: String) -> Result<(), String> {
    OAUTH_SERVER.start("127.0.0.1:8888", state, move |url| {
        let _ = app.emit("spotify-callback", url);
    }).await.map(|_| ()).map_err(|e| format!("OAuth listener failed: {e}"))
}

#[tauri::command]
pub async fn cancel_oauth_listener() {
    OAUTH_SERVER.cancel().await;
}

#[tauri::command]
pub fn clear_refresh_token(app: AppHandle) -> Result<(), String> {
    // 키체인 + 레거시 파일 모두 제거
    if let Ok(entry) = keyring_entry() {
        let _ = entry.delete_credential();
    }
    let path = token_path(&app)?;
    if path.exists() {
        std::fs::remove_file(&path).map_err(|e| format!("토큰 삭제 실패: {e}"))?;
    }
    Ok(())
}

#[cfg(test)]
mod token_file_tests {
    use super::write_restricted_token_file;

    #[cfg(unix)]
    #[test]
    fn refresh_token_file_is_created_with_owner_only_permissions() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("token.dat");

        write_restricted_token_file(&path, "secret-token").unwrap();

        assert_eq!(std::fs::metadata(path).unwrap().permissions().mode() & 0o777, 0o600);
    }
}
